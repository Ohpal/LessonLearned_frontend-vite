import { importShared } from "./__federation_fn_import-Dc6jQS63.js";
import { _ as _export_sfc } from "./_plugin-vue_export-helper-1tPrXgE0.js";
const _imports_0 = "./../media/ready-DG9wqz_I.ready.png";
const _sfc_main = {};
const { createElementVNode: _createElementVNode, openBlock: _openBlock, createElementBlock: _createElementBlock } = await importShared("vue");
const _hoisted_1 = { class: "row" };
function _sfc_render(_ctx, _cache) {
  return _openBlock(), _createElementBlock("div", _hoisted_1, _cache[0] || (_cache[0] = [
    _createElementVNode("div", { class: "container-fluid px-4" }, [
      _createElementVNode("div", { class: "d-flex justify-content-center load_middle" }, [
        _createElementVNode("img", {
          src: _imports_0,
          width: "500"
        })
      ])
    ], -1)
  ]));
}
const NowReady = /* @__PURE__ */ _export_sfc(_sfc_main, [["render", _sfc_render]]);
export {
  NowReady as default
};
